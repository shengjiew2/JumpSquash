﻿using UnityEngine;
using System.Collections;

public class SingleShaderScript : MonoBehaviour
{
    
   
    // Use this for initialization
    void Start()
    {
        this.GetComponent<unitInterface>().highlightAsMovable();

    }

    




}
