﻿using UnityEngine;
using System.Collections;

public class ShadowScript : MonoBehaviour {

    public GameObject parent;

	// Use this for initialization
	void Start () {
	    
	}
	
	// Update is called once per frame
	void Update () {
        this.transform.position = parent.transform.position;
        this.transform.rotation = parent.transform.rotation;
	}
}
