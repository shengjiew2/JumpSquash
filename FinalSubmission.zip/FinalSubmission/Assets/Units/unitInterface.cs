﻿using UnityEngine;
using System.Collections;

public class unitInterface : MonoBehaviour {


    //how this interacts with the board/pebbles will be done later, but works for now.
    public Stone currStone;
    public BoardInterface board;
    bouncyController control; //handles the detailed stuff like trajectory calculation
    public int id; //will be 0-4 and intruct which position is the home row
    public int status; //HOME = 0, FEILD = 1; TARGET = 2;
    public int player;
    public int highlight; // 0 is normal, 1 highlight1, ect. 



    public const int HOME = 0;
    public const int FEILD = 1;
    public const int TARGET = 2;

    private bool feildMoving = false;


    // Use this for initialization
    void Start()
    {
        //these initialisation stuffs aren't getting executed. WHY NOT? Maybe only once per game?
        control = this.GetComponent<bouncyController>();

    }
    public void setUp()
    {
        control = this.GetComponent<bouncyController>();
        
        highlight = 0;
        status = 0;
    }

    public const int NORMAL = 0;
    public const int MOVABLE = 1;
    public const int MOVING = 2;


    public void highlightAsMovable()
    {
        highlight = MOVABLE;
        control.setShader_sparklySmall();
    }

    public void movePlaces(int n)
    {
        highlightAsMoving();
        currStone.occupiedBy = null;
        if (this.status == HOME)
        {
            moveTo(board.stoneList[board.startStones[player]]);
            status = FEILD;
            feildMoving = false;
        }
        else
        {
            numToJump = n;
            feildMoving = true;
        }

    }

    public void highlightAsMoving()
    {
        highlight = MOVING;
        control.setShader_sparklyBig();
    }


    public void highlightAsImmovable()
    {
        if (highlight == MOVABLE)
        {
            highlight = NORMAL;
            control.setShader_normal();
        }
    }

    public void highlightAsUnmoving()
    {
        highlight = NORMAL;
        if (status == FEILD || status == HOME)
        {
            control.setShader_normal();
        }

        if (status == TARGET)
        {
            control.setShader_grey();
        }

    }

    // Update is called once per frame
    void Update()
    {
        /*

        //tester functins
        if (Input.GetKeyDown("n"))
        {
            print("got input n");
            movePlaces(3);
        }

        if (Input.GetKeyDown("1")) highlight1();
        if (Input.GetKeyDown("2")) highlight2();

        */


        if (highlight == MOVING)
        {
            if(status == TARGET)
            {
                highlightAsUnmoving();
            }

            //bounce again if you're on your way somewhere
            if (!control.smallBouncing && numToJump > 0)
            {
                //set target as next pebble
                Stone nextStone = board.stoneList[(currStone.index + 1) % board.stoneList.Length];
                moveTo(nextStone);
                numToJump--;
            }

            //wait for it to finish the final bounce, then stop moving. 
            if (!control.smallBouncing && !control.bouncing && numToJump == 0 && !feildMoving)
            {
                
                highlightAsUnmoving();

            }

            


            //if you're still in the field (ie. moving n places) then you have to wait for the final jump to finish
            if (!control.smallBouncing && !control.bouncing && numToJump == 0 && feildMoving && !buffered)
            {
                
                
                waitForIt = control.bounceCount + 1;
                
                buffered = true;

            }

            if (!control.smallBouncing && numToJump == 0 && !control.bouncing && control.bounceCount >= waitForIt && feildMoving&& buffered)
            {
                
                buffered = false;
                highlightAsUnmoving();
            }
            
        }
    }

    private bool buffered = false;

    private int waitForIt = 0;

    /*
    public void highlight0()
    {
        //change back
        highlight = 0;
        control.setShader_normal();

    }

    public void highlight1()
    {
        //change colour and bobble ears
        control.earBobble();
        highlight = 1;
        control.setShader_sparklySmall();
    }

    public void highlight2()
    {
        highlight = 2;
        control.bobble();
        control.setShader_sparklyBig();
        //change colour and bobble head
    }

    public void highlightLOCKED()
    {
        highlight = 3;
        //turn grey
        control.setShader_grey();
    }
    */
    public void teleportTo(Stone stone)
    {
        this.transform.position = stone.pos + Vector3.up * 3;
    }

    public void setUpShaders(PointLight pointLight)
    {
        control.setUpShaders(pointLight);
    }

    public void moveTo(Stone stone)
    {
        //if you're about to make it back to the start stone, go 
        //to your home row instead
        if (status == FEILD && stone.index == board.startStones[player])
        {
            numToJump = 0;
            feildMoving = false;
            sendToTarget();
            return;
        }
        
        //small set target to stone's position
        control.targetX = stone.pos.x;
        control.targetZ = stone.pos.z;
        currStone = stone;
    }

    public int numToJump = 0;

    public void sendToTarget()
    {
        Stone stone = board.targetRows[player][id];
        status = TARGET;
        numToJump = 0;
        control.setShader_grey();
        moveTo(stone);

        /*
        //small set target to stone's position
        control.targetX = stone.pos.x;
        control.targetZ = stone.pos.z;
        currStone = stone;
        status =TARGET;
        numToJump = 0;
        feildMoving = false;
        highlight = MOVING;
        control.setShader_grey();
        */

    }

    public void sendHome()
    {
        //currStone.occupiedBy = opponentPeice
        moveTo(board.homeRows[player][id]);
        status = HOME;
    }

    

  






}
