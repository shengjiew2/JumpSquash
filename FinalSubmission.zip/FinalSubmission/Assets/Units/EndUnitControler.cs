﻿using UnityEngine;
using System.Collections;




public class EndUnitControler : MonoBehaviour {

    public GameObject unit;
    public PointLight pointLight;

    private bouncyController control;
    private unitInterface I;

    public bool ready = false;

    // Use this for initialization
    void Start () {
        ready = false;
        

	
	}
	
	// Update is called once per frame
	void Update () {
        if (!ready)
        {
            control = unit.GetComponent<bouncyController>();
            I = unit.GetComponent<unitInterface>();
            control.setUpShaders(pointLight);
            control.setShader_sparklyBig();
            ready = true;
            //control.setShader_grey();
            print("Applied shader!");

        }

    }
}
