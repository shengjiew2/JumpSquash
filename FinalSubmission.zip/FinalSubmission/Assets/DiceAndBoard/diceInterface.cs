﻿using UnityEngine;
using System.Collections;

public class diceInterface : MonoBehaviour {

    private DisplayCurrentValue value;
    private ApplyForceInRandomDirection thrower;
    //public GameObject dice;
	// Use this for initialization
	void Start () {
	    value = this.GetComponent<DisplayCurrentValue>();
        thrower = this.GetComponent<ApplyForceInRandomDirection>();
    }

    
    private float timeStopped = 0;

	// Update is called once per frame
	void Update () {
        if (GetComponent<Rigidbody>().velocity.magnitude < stillnessThreshold)
        {
            timeStopped += Time.deltaTime;

        }
        else
        {
            timeStopped = 0;
        }


    }

    public void roll()
    {
        thrower.Throw();
    }

    public float timeThreshold = 0.2f;

    public bool hasStopped()
    {
        stopped = timeStopped >= timeThreshold;
        return timeStopped >= timeThreshold;
    }

    public bool stopped  = false;

    public int getResult()
    {
        
        return value.currentValue;
       
    }

    public float stillnessThreshold;

}
