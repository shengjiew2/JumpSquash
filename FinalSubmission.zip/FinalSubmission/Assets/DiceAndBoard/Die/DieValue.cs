﻿using UnityEngine;
using System.Collections;

public class DieValue : MonoBehaviour {
    public int value = 1;
}
