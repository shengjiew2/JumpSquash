﻿


using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;

public class GameLogicScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
        setUp();
	
	}
    public const int numPlayers = 2;

    public GameObject boardObject;
    private BoardInterface board;

    public PointLight pointLight;

    //public GameObject instructionPromptObject;
    public GameObject okayPromptObject;
    private InstructionScript iPrompt;
    private OKscript okPrompt;
    

    public GameObject unitPrefabP1;
    public GameObject unitPrefabP2;

    public GameObject diceObject; //this can be a child of the board, but would be nice to access directly
    private diceInterface dice;
    private int gameMode = 0;
    private int whoseTurn;
    private int subMode;

    

    private int diceResult = 1;

    //gameMode constants
    const int SETUP = 0;
    const int TURNS = 1;
    const int GAMEOVER = 2;
    //subMode constants



    const int STARTING_TURN = 0;
    const int WAITING_FOR_OKAY = 1;
    const int WAITING_FOR_ROLL = 2;
    const int WAITING_FOR_DICE_RESULTS = 3;
    const int WAITING_FOR_UNIT_SELECTION = 4;
    const int MOVING_UNIT = 5;

    public unitInterface movingUnit = null;

    private int inputMode = MOUSE;

    private const int MOUSE = 0;
    private const int ACCEL = 1;

    public const float shakeThresh = 1;
    public Text accel;
    // Update is called once per frame
    void Update () {

        if (Input.acceleration.magnitude!= 0)
        {
            inputMode = ACCEL;
            accel.text = Input.acceleration.ToString();
            //Debug.Log(Input.acceleration);

        }
        

        switch (gameMode)
        {   case SETUP:
                //if we're still setting up, dont want to do anything
                break;
            case TURNS:
                switch (subMode)
                {
                    case STARTING_TURN:
                        //tell player it's their turn, wait for okay
                        //move the camera 
                        okPrompt.setMainText("Player " + (whoseTurn + 1) + "'s Turn");
                        okPrompt.open();
                        subMode = WAITING_FOR_OKAY;
                        print("waiting for okay");
                        break;
                    case WAITING_FOR_OKAY:
                        if (okPrompt.okClicked) //if player has pressed okay
                        {
                            okPrompt.close();
                            subMode = WAITING_FOR_ROLL;
                            print("waiting for roll");
                        }
                        break;
                    case WAITING_FOR_ROLL:
                        if (Input.GetMouseButton(0) || (inputMode == ACCEL && Input.acceleration.magnitude > 1.2))
                            
                        {
                            print("rolling");
                            dice.roll();
                    
                            subMode = WAITING_FOR_DICE_RESULTS;
                        }
                        break;
                    case WAITING_FOR_DICE_RESULTS:
                        if (dice.hasStopped())
                        {
                            diceResult = dice.getResult();
                            print("result: " + diceResult);
                            int numMovable = highlightMovableUnits(diceResult);
                            print(numMovable + " movable units");
                            if (numMovable == 0)
                            {
                                endTurn();
                            }
                            else
                            {
                                subMode = WAITING_FOR_UNIT_SELECTION;
                                //open instruction window to touch a movable player
                            }
                        }

                        break;
                    case WAITING_FOR_UNIT_SELECTION:
                        if (Input.GetMouseButton(0))
                        {
                            unitInterface U;
                            print("clicked");
                            if ((U = (unitInterface)getClickedOnUnit()) != null)
                            {
                                //endTurn();
                                movingUnit = U;
                                subMode = MOVING_UNIT;
                                //print("found unit");       
                                //U.highlight2();
                                unlightAllUnits1();
                                if (FASTMODE) U.movePlaces(diceResult*3);
                                else  U.movePlaces(diceResult);

                            }
                            
                        }
                        break;
                    case MOVING_UNIT:
                        {
                            if (movingUnit.highlight != MOVING)
                            {   
                                
                                if (movingUnit.currStone.occupiedBy != null)
                                {
                                    movingUnit.currStone.occupiedBy.sendHome();
                                }

                                movingUnit.currStone.occupiedBy = movingUnit;

                                /*
                                if (movingUnit.status != TARGET)
                                {
                                    movingUnit.highlight0();
                                }
                                */
                                endTurn();
                            }
                        }



                        break;





                }




                //tell player to roll dice
                //understand that player has pressed okay
                //wait for player to roll dice
                //get result of dice roll
                //tell player to select unit
                    //highlight selectable units
                    //if no selectable units, tell player
                    //wait for okay,
                    //next players turn           
                //wait for player to select unit
                //ask player if sure
                //wait for player to confirm or cancel
                //if cancel, go back
                //else, move unit dice places
                //if land on other, 
                    //move other back home
                //wait for unit to finish
                //next players turn


                break;
            case GAMEOVER:
                if (winner == 0)
                {
                    Application.LoadLevel(2);
                }
                if (winner == 1)
                {
                    Application.LoadLevel(3);
                }
                //Application.LoadLevel(2);
                //switch to the congratulations sceen, etc.
                break;
            
        }

            
           
	}


    public void toggleFastMode()
    {
        FASTMODE = !FASTMODE;
    }

    /*unlight all highlighted 1 units*/
    private void unlightAllUnits1()
    {
        foreach (GameObject unit in unitLists[whoseTurn])
        {
            unitInterface I = unit.GetComponent<unitInterface>();
            if (I.highlight == MOVABLE)
            {
                I.highlightAsImmovable();
            }
            
        }
    }

    private int winner;

    void endTurn()
    {
        //check if the current player has won
        Boolean won = true;
        foreach (GameObject unit in unitLists[whoseTurn])
        {
            unitInterface I = unit.GetComponent<unitInterface>();
            if (I.status != TARGET)
            {
                won = false;
                break;
            }
        }

        if (won)
        {
            winner = whoseTurn;
            gameMode = GAMEOVER;
        }

        whoseTurn = (whoseTurn + 1) % numPlayers;
        subMode = STARTING_TURN;
    }

    //unit constants

    unitInterface getClickedOnUnit()
    {
        //if clicked on object has no unitInterface (ie, is not a unit) will return null
        //or if nothing hit
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (!Physics.Raycast(ray, out hit, 1000))
        {
            //print("got nothing");
            return null;
        }
       // print("got something");

        GameObject hitObject = hit.transform.gameObject;
        //print(hit.transform);

        unitInterface I = hitObject.GetComponentInParent<unitInterface>();

        if (I == null) return null;
        if (I.highlight == MOVABLE) return I;
        return null;

        
        

        
    }

    //unit status constants
    const int HOME = 0;
    const int FEILD = 1; 
    const int TARGET = 2;

    //unit highlight constants
    public const int NORMAL = 0;
    public const int MOVABLE = 1;
    public const int MOVING = 2;

    public bool FASTMODE = false;

    int highlightMovableUnits(int n)
    { 
        //return number of movable units
        int c = 0;

        //if they roll a 6 or a 5and start pebble not occupied, highlight all in homerow
        if ((n == 6 ||n==5) && (!(board.stoneList[board.startStones[whoseTurn]].occupiedBy) || board.stoneList[board.startStones[whoseTurn]].occupiedBy.player != whoseTurn))
        {
            foreach (GameObject unit in unitLists[whoseTurn])
            {
                unitInterface I = unit.GetComponent<unitInterface>();
                if (I.status == HOME)
                {

                    I.highlightAsMovable();
                    c++;

                }

            }


        }


        //Then highlight all movable objects in feild
        foreach (GameObject unit in unitLists[whoseTurn])

        {

            unitInterface I = unit.GetComponent<unitInterface>();

            if (I.status == FEILD)

            {
                //first, check if they can make it into their target row
                
                int targetIndex = (I.currStone.index + n) % (board.stoneList.Length);
                             
                for (int i = 1; i <= n; i++)
                {
                    if (((I.currStone.index + i) % board.stoneList.Length) == board.startStones[whoseTurn])

                    { //then they can make it to target and should be highlighted. 
             
                        if (I.highlight != MOVABLE)
                        {
                            I.highlightAsMovable();
                            c++;
                        }
                    }

                }

                //if target stone is not occupied, or occupied by opponent players only
                if (!(board.stoneList[targetIndex].occupiedBy) || !(board.stoneList[targetIndex].occupiedBy.player == whoseTurn))
                {
                    if (I.highlight != MOVABLE)
                    {
                        I.highlightAsMovable();
                        c++;
                    }
                }
            }
        }
       
        return c;       
    }




    void setUp()
    {



        //board and stones
        board = boardObject.GetComponent<BoardInterface>();
        board.generateStoneLists();

        //dice
        dice = diceObject.GetComponent<diceInterface>();

        //prompts
        //iPrompt = instructionPromptObject.GetComponent<InstructionScript>();
        //iPrompt.close();
        okPrompt = okayPromptObject.GetComponent<OKscript>();
        okPrompt.close();

        //units
        addUnitsToBoard();

        //if finished setting up, start game
        startGame();
    }

    private void startGame()
    {
        gameMode = TURNS;
        whoseTurn = 0;
        subMode = STARTING_TURN;
    }
    

    public GameObject[][] unitLists;
    
    public const int numUnits = 3; //each
    
    void addUnitsToBoard()
    { 
        
        //create units and put them on the homeRow
        
        unitLists = new GameObject[numPlayers][];
        unitLists[0] = new GameObject[numUnits];
        unitLists[1] = new GameObject[numUnits];

        GameObject[] unitPrefabs  = new GameObject[numPlayers];
        unitPrefabs[0] = unitPrefabP1;
        unitPrefabs[1] = unitPrefabP2;

        unitInterface I;
        for (int p = 0; p < numPlayers; p++)
        {
            for (int i = 0; i < numUnits; i++)
            {
                print("adding units to board" + i);
                unitLists[p][i] = Instantiate(unitPrefabs[p]); //instanceunitPrefabP1
                I = unitLists[p][i].GetComponent<unitInterface>();
                I.setUp();
                I.board = board;
                I.currStone = board.homeRows[p][i];
                I.teleportTo(I.currStone);
                I.moveTo(I.currStone);
                I.player = p;
                I.id = i;
                I.setUpShaders(pointLight);

            }
        }
        
    }

    /*
    Board:
    has an array of stones for the path
    has an index of start/finish stones for player one and two
    has arrays of start/end stones for player one and two
    
    these arrays should have xy co-oridnates, relative to the board or not? i dont know

    has a dice
    has a roll dice method
    has finished rolling attribute
    has result attibe
    sends dice answer message to main script

    */


   

}
