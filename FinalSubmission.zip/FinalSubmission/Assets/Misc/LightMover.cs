﻿using UnityEngine;
using System.Collections;

public class LightMover : MonoBehaviour {

    public Vector3 mainPos;
    public float speed; //degrees per second

	// Use this for initialization
	void Start () {
        mainPos = this.transform.position;
        transform.position = transform.position + Vector3.up;
	}
	
	// Update is called once per frame
	void Update () {

        transform.RotateAround(mainPos, Vector3.right, speed*Time.deltaTime);

	}
}
