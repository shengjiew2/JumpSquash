﻿using UnityEngine;
using System.Collections;

public class ChangeScene : MonoBehaviour {

	public void ChnageToScene(int sceneToChangeTo)
    {
        Application.LoadLevel(sceneToChangeTo);

    }
    public void Quit()
    {
        Application.Quit();
    }
}
